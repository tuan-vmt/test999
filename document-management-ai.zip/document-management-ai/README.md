# README.md
# Document Management System with AI Sensitive Data Detection

## Hướng dẫn cài đặt và chạy ứng dụng

### Yêu cầu hệ thống
- Python 3.8+
- MongoDB 4.0+
- OpenAI API Key

### Cài đặt nhanh

```bash
# Clone hoặc tạo project directory
mkdir document-management && cd document-management

# Chạy script cài đặt
chmod +x install.sh
./install.sh

# Cập nhật API key trong file .env
nano .env

# Chạy ứng dụng
source venv/bin/activate
python run.py
```

### Cài đặt thủ công

1. **Tạo virtual environment:**
```bash
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# hoặc
venv\Scripts\activate     # Windows
```

2. **Cài đặt dependencies:**
```bash
pip install -r requirements.txt
```

3. **Tạo file .env:**
```bash
SECRET_KEY=your-secret-key-here
MONGODB_URL=mongodb://localhost:27017
DATABASE_NAME=document_management
OPENAI_API_KEY=your-openai-api-key
MAX_FILE_SIZE=10485760
UPLOAD_DIR=uploads
```

4. **Chạy ứng dụng:**
```bash
python run.py
```

### Sử dụng Docker

```bash
# Build và chạy với docker-compose
docker-compose up --build

# Ứng dụng sẽ chạy tại http://localhost:8000
```

### Tính năng chính

1. **Đăng nhập/Đăng ký người dùng**
2. **Upload tài liệu PDF/DOCX**
3. **Rà quét tự động với AI**
4. **Phát hiện thông tin nhạy cảm**
5. **Cảnh báo bảo mật**
6. **Chia sẻ tài liệu có kiểm soát**

### API Endpoints

- `POST /api/register` - Đăng ký
- `POST /api/login` - Đăng nhập
- `GET /api/me` - Thông tin user
- `POST /api/upload` - Upload file
- `GET /api/documents` - Danh sách tài liệu
- `GET /api/documents/{id}` - Chi tiết tài liệu
- `POST /api/documents/{id}/share` - Chia sẻ tài liệu

### Test Cases

Ứng dụng pass tất cả test cases trong file PDF được cung cấp:
- TC1-TC7: Đăng nhập và xác thực
- TC8-TC13: Upload tài liệu
- TC14-TC19: Rà quét dữ liệu nhạy cảm
- TC20-TC27: Xem tài liệu
- TC28-TC31: Chia sẻ tài liệu (nâng cao)