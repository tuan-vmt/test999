# main.py
from fastapi import FastAPI, Depends, HTTPException, status, File, UploadFile, Form
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.requests import Request
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import asyncio
import os
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import json
import re
import aiofiles
import shutil
from pathlib import Path

# Database and Models
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, EmailStr
from bson import ObjectId
import pymongo

# Authentication
from passlib.context import CryptContext
from jose import JWTError, jwt

# Document Processing
import docx
import PyPDF2
import openai
from io import BytesIO

# Environment variables
from dotenv import load_dotenv
load_dotenv()

# Configuration
class Settings:
    SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here")
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = 30
    MONGODB_URL = os.getenv("MONGODB_URL", "mongodb://localhost:27017")
    DATABASE_NAME = "document_management"
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "your-openai-api-key")
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    UPLOAD_DIR = "uploads"

settings = Settings()

# Create upload directory
Path(settings.UPLOAD_DIR).mkdir(exist_ok=True)

# Initialize OpenAI
openai.api_key = settings.OPENAI_API_KEY

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT token handling
security = HTTPBearer()

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt

# Pydantic Models
class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: Optional[str] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(BaseModel):
    id: Optional[str] = None
    email: EmailStr
    full_name: Optional[str] = None
    is_active: bool = True
    created_at: datetime = datetime.utcnow()
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            ObjectId: str
        }

class Document(BaseModel):
    id: Optional[str] = None
    filename: str
    original_filename: str
    file_path: str
    file_size: int
    file_type: str
    owner_id: str
    upload_date: datetime = datetime.utcnow()
    scan_status: str = "pending"  # pending, processing, completed, failed
    has_sensitive_data: bool = False
    sensitive_data_details: List[Dict[str, Any]] = []
    shared_with: List[str] = []
    is_public: bool = False
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            ObjectId: str
        }

class SensitiveDataPattern:
    """Patterns for detecting sensitive information"""
    
    PATTERNS = {
        "phone_number": {
            "pattern": r"(\+84|0)[1-9]\d{8,9}",
            "description": "Số điện thoại",
            "category": "personal_identification"
        },
        "cmnd_cccd": {
            "pattern": r"\b\d{9,12}\b",
            "description": "Số CMND/CCCD",
            "category": "personal_identification"
        },
        "email": {
            "pattern": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
            "description": "Email",
            "category": "personal_identification"
        },
        "bank_account": {
            "pattern": r"\b\d{10,20}\b",
            "description": "Số tài khoản ngân hàng",
            "category": "financial_info"
        },
        "tax_code": {
            "pattern": r"\b\d{10,13}\b",
            "description": "Mã số thuế",
            "category": "organization_identification"
        },
        "api_key": {
            "pattern": r"(api[_-]?key|access[_-]?token|secret[_-]?key)['\"]?\s*[:=]\s*['\"]?[A-Za-z0-9_-]{20,}",
            "description": "API Key/Access Token",
            "category": "secret_credentials"
        },
        "password": {
            "pattern": r"(password|pass|pwd)['\"]?\s*[:=]\s*['\"]?[A-Za-z0-9!@#$%^&*()_+-=]{6,}",
            "description": "Mật khẩu",
            "category": "secret_credentials"
        }
    }

# Database connection
class Database:
    client: AsyncIOMotorClient = None
    database = None

db = Database()

async def get_database():
    return db.database

async def connect_to_mongo():
    db.client = AsyncIOMotorClient(settings.MONGODB_URL)
    db.database = db.client[settings.DATABASE_NAME]
    
    # Create indexes
    await db.database.users.create_index("email", unique=True)
    await db.database.documents.create_index("owner_id")
    await db.database.documents.create_index("filename")

async def close_mongo_connection():
    if db.client:
        db.client.close()

# Document processing functions
async def extract_text_from_pdf(file_content: bytes) -> str:
    try:
        pdf_file = BytesIO(file_content)
        pdf_reader = PyPDF2.PdfReader(pdf_file)
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text()
        return text
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing PDF: {str(e)}")

async def extract_text_from_docx(file_content: bytes) -> str:
    try:
        doc_file = BytesIO(file_content)
        doc = docx.Document(doc_file)
        text = ""
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        return text
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing DOCX: {str(e)}")

async def detect_sensitive_data_with_ai(text: str) -> List[Dict[str, Any]]:
    """Use ChatGPT to detect sensitive information"""
    try:
        # First, use regex patterns for quick detection
        detected_data = []
        
        for pattern_name, pattern_info in SensitiveDataPattern.PATTERNS.items():
            matches = re.finditer(pattern_info["pattern"], text, re.IGNORECASE)
            for match in matches:
                detected_data.append({
                    "type": pattern_name,
                    "description": pattern_info["description"],
                    "category": pattern_info["category"],
                    "value": match.group(),
                    "position": {
                        "start": match.start(),
                        "end": match.end()
                    },
                    "confidence": 0.8
                })
        
        # Use ChatGPT for advanced detection
        prompt = f"""
        Analyze the following text and identify any sensitive information that might pose security risks.
        Look for:
        1. Personal identification numbers (ID, passport, driver license)
        2. Financial information (bank accounts, credit cards)
        3. Contact information (emails, phone numbers)
        4. API keys, passwords, tokens
        5. Tax codes or business identification numbers
        
        Text to analyze:
        {text[:2000]}...  # Limit text length for API
        
        Return only a JSON array with detected items in this format:
        [
            {{
                "type": "data_type",
                "description": "Vietnamese description",
                "category": "category_name",
                "value": "detected_value",
                "confidence": 0.9
            }}
        ]
        """
        
        try:
            response = await openai.ChatCompletion.acreate(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=1000
            )
            
            ai_result = response.choices[0].message.content
            # Parse AI response and merge with regex results
            try:
                ai_detected = json.loads(ai_result)
                detected_data.extend(ai_detected)
            except json.JSONDecodeError:
                pass  # Continue with regex results only
                
        except Exception as ai_error:
            print(f"AI detection error: {ai_error}")
            # Continue with regex results only
        
        return detected_data
        
    except Exception as e:
        print(f"Sensitive data detection error: {e}")
        return []

async def scan_document(document_id: str):
    """Background task to scan document for sensitive data"""
    try:
        database = await get_database()
        
        # Update status to processing
        await database.documents.update_one(
            {"_id": ObjectId(document_id)},
            {"$set": {"scan_status": "processing"}}
        )
        
        # Get document info
        doc = await database.documents.find_one({"_id": ObjectId(document_id)})
        if not doc:
            return
        
        # Read file content
        async with aiofiles.open(doc["file_path"], "rb") as f:
            file_content = await f.read()
        
        # Extract text based on file type
        if doc["file_type"] == "application/pdf":
            text = await extract_text_from_pdf(file_content)
        elif doc["file_type"] in ["application/vnd.openxmlformats-officedocument.wordprocessingml.document"]:
            text = await extract_text_from_docx(file_content)
        else:
            raise Exception("Unsupported file type")
        
        # Detect sensitive data
        sensitive_data = await detect_sensitive_data_with_ai(text)
        
        # Update document with results
        await database.documents.update_one(
            {"_id": ObjectId(document_id)},
            {
                "$set": {
                    "scan_status": "completed",
                    "has_sensitive_data": len(sensitive_data) > 0,
                    "sensitive_data_details": sensitive_data
                }
            }
        )
        
    except Exception as e:
        # Update status to failed
        database = await get_database()
        await database.documents.update_one(
            {"_id": ObjectId(document_id)},
            {"$set": {"scan_status": "failed", "error_message": str(e)}}
        )

# Authentication functions
async def get_user_by_email(email: str):
    database = await get_database()
    user = await database.users.find_one({"email": email})
    return user

async def authenticate_user(email: str, password: str):
    user = await get_user_by_email(email)
    if not user:
        return False
    if not verify_password(password, user["password"]):
        return False
    return user

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(credentials.credentials, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    
    user = await get_user_by_email(email)
    if user is None:
        raise credentials_exception
    return user

# FastAPI app
app = FastAPI(title="Document Management System", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files and templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Events
@app.on_event("startup")
async def startup_event():
    await connect_to_mongo()

@app.on_event("shutdown")
async def shutdown_event():
    await close_mongo_connection()

# Routes
@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

# Authentication endpoints
@app.post("/api/register")
async def register(user: UserCreate):
    database = await get_database()
    
    # Check if user exists
    existing_user = await database.users.find_one({"email": user.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create user
    hashed_password = get_password_hash(user.password)
    user_dict = {
        "email": user.email,
        "password": hashed_password,
        "full_name": user.full_name,
        "is_active": True,
        "created_at": datetime.utcnow()
    }
    
    result = await database.users.insert_one(user_dict)
    
    # Create access token
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/api/login")
async def login(user: UserLogin):
    authenticated_user = await authenticate_user(user.email, user.password)
    if not authenticated_user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": authenticated_user["email"]}, expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/api/me")
async def read_users_me(current_user: dict = Depends(get_current_user)):
    return {
        "id": str(current_user["_id"]),
        "email": current_user["email"],
        "full_name": current_user.get("full_name"),
        "is_active": current_user["is_active"]
    }

# Document endpoints
@app.post("/api/upload")
async def upload_document(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    # Validate file type
    if file.content_type not in ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only PDF and DOCX files are allowed."
        )
    
    # Read file content to check size
    content = await file.read()
    if len(content) > settings.MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"File too large. Maximum size is {settings.MAX_FILE_SIZE // (1024*1024)}MB"
        )
    
    # Generate unique filename
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filename = f"{timestamp}_{file.filename}"
    file_path = os.path.join(settings.UPLOAD_DIR, filename)
    
    # Save file
    async with aiofiles.open(file_path, "wb") as f:
        await f.write(content)
    
    # Save document info to database
    database = await get_database()
    document_dict = {
        "filename": filename,
        "original_filename": file.filename,
        "file_path": file_path,
        "file_size": len(content),
        "file_type": file.content_type,
        "owner_id": str(current_user["_id"]),
        "upload_date": datetime.utcnow(),
        "scan_status": "pending",
        "has_sensitive_data": False,
        "sensitive_data_details": [],
        "shared_with": [],
        "is_public": False
    }
    
    result = await database.documents.insert_one(document_dict)
    document_id = str(result.inserted_id)
    
    # Start background scanning
    asyncio.create_task(scan_document(document_id))
    
    return {
        "message": "File uploaded successfully",
        "document_id": document_id,
        "status": "uploaded"
    }

@app.get("/api/documents")
async def list_documents(current_user: dict = Depends(get_current_user)):
    database = await get_database()
    
    # Get documents owned by user or shared with user
    cursor = database.documents.find({
        "$or": [
            {"owner_id": str(current_user["_id"])},
            {"shared_with": str(current_user["_id"])},
            {"is_public": True}
        ]
    })
    
    documents = []
    async for doc in cursor:
        doc["_id"] = str(doc["_id"])
        documents.append(doc)
    
    return {"documents": documents}

@app.get("/api/documents/{document_id}")
async def get_document(document_id: str, current_user: dict = Depends(get_current_user)):
    database = await get_database()
    
    # Check if document exists and user has access
    doc = await database.documents.find_one({"_id": ObjectId(document_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    
    user_id = str(current_user["_id"])
    if not (doc["owner_id"] == user_id or user_id in doc["shared_with"] or doc["is_public"]):
        raise HTTPException(status_code=403, detail="No permission to access this document")
    
    if doc["scan_status"] != "completed":
        return {
            "status": doc["scan_status"],
            "message": "Document is still being processed" if doc["scan_status"] == "processing" else "Document processing failed"
        }
    
    doc["_id"] = str(doc["_id"])
    return doc

@app.post("/api/documents/{document_id}/share")
async def share_document(
    document_id: str,
    user_emails: List[str],
    current_user: dict = Depends(get_current_user)
):
    database = await get_database()
    
    # Check if user owns the document
    doc = await database.documents.find_one({"_id": ObjectId(document_id)})
    if not doc or doc["owner_id"] != str(current_user["_id"]):
        raise HTTPException(status_code=403, detail="You can only share documents you own")
    
    # Get user IDs for the emails
    user_ids = []
    for email in user_emails:
        user = await database.users.find_one({"email": email})
        if user:
            user_ids.append(str(user["_id"]))
    
    # Update document sharing
    await database.documents.update_one(
        {"_id": ObjectId(document_id)},
        {"$addToSet": {"shared_with": {"$each": user_ids}}}
    )
    
    return {"message": "Document shared successfully", "shared_with_count": len(user_ids)}

@app.get("/api/documents/{document_id}/download")
async def download_document(document_id: str, current_user: dict = Depends(get_current_user)):
    database = await get_database()
    
    # Check access permissions
    doc = await database.documents.find_one({"_id": ObjectId(document_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    
    user_id = str(current_user["_id"])
    if not (doc["owner_id"] == user_id or user_id in doc["shared_with"] or doc["is_public"]):
        raise HTTPException(status_code=403, detail="No permission to access this document")
    
    # Return file
    from fastapi.responses import FileResponse
    return FileResponse(
        path=doc["file_path"],
        filename=doc["original_filename"],
        media_type=doc["file_type"]
    )

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)