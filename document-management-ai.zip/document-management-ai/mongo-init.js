db = db.getSiblingDB('document_management');

db.createUser({
  user: 'app_user',
  pwd: 'app_password',
  roles: [
    {
      role: 'readWrite',
      db: 'document_management'
    }
  ]
});

// Create collections and indexes
db.createCollection('users');
db.createCollection('documents');

db.users.createIndex({ "email": 1 }, { unique: true });
db.documents.createIndex({ "owner_id": 1 });
db.documents.createIndex({ "filename": 1 });
db.documents.createIndex({ "upload_date": -1 });

print('Database initialized successfully');