// Main JavaScript for Document Management System

class DocumentManager {
    constructor() {
        this.token = localStorage.getItem('access_token');
        this.currentUser = null;
        this.documents = [];
        this.init();
    }

    async init() {
        await this.checkAuth();
        this.setupEventListeners();
        if (this.isLoggedIn()) {
            await this.loadDocuments();
        }
    }

    isLoggedIn() {
        return !!this.token;
    }

    async checkAuth() {
        if (!this.token) return false;

        try {
            const response = await this.apiCall('/api/me');
            if (response.ok) {
                this.currentUser = await response.json();
                this.updateUI();
                return true;
            } else {
                this.logout();
                return false;
            }
        } catch (error) {
            console.error('Auth check failed:', error);
            this.logout();
            return false;
        }
    }

    async apiCall(url, options = {}) {
        const headers = {
            'Content-Type': 'application/json',
            ...options.headers
        };

        if (this.token) {
            headers.Authorization = `Bearer ${this.token}`;
        }

        const response = await fetch(url, {
            ...options,
            headers
        });

        if (response.status === 401) {
            this.logout();
            throw new Error('Unauthorized');
        }

        return response;
    }

    async login(email, password) {
        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok) {
                this.token = data.access_token;
                localStorage.setItem('access_token', this.token);
                await this.checkAuth();
                return { success: true };
            } else {
                return { success: false, error: data.detail };
            }
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async register(email, password, fullName) {
        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    email, 
                    password, 
                    full_name: fullName 
                })
            });

            const data = await response.json();

            if (response.ok) {
                this.token = data.access_token;
                localStorage.setItem('access_token', this.token);
                await this.checkAuth();
                return { success: true };
            } else {
                return { success: false, error: data.detail };
            }
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    logout() {
        this.token = null;
        this.currentUser = null;
        this.documents = [];
        localStorage.removeItem('access_token');
        this.updateUI();
        window.location.href = '/login';
    }

    updateUI() {
        const userNav = document.getElementById('userNav');
        const loginNav = document.getElementById('loginNav');
        const userName = document.getElementById('userName');

        if (this.currentUser) {
            if (userNav) userNav.style.display = 'block';
            if (loginNav) loginNav.style.display = 'none';
            if (userName) userName.textContent = this.currentUser.email;
        } else {
            if (userNav) userNav.style.display = 'none';
            if (loginNav) loginNav.style.display = 'block';
        }
    }

    async loadDocuments() {
        try {
            const response = await this.apiCall('/api/documents');
            if (response.ok) {
                const data = await response.json();
                this.documents = data.documents;
                this.displayDocuments();
                this.updateStatistics();
            }
        } catch (error) {
            console.error('Error loading documents:', error);
        }
    }

    displayDocuments() {
        const tbody = document.querySelector('#documentsTable tbody');
        if (!tbody) return;

        tbody.innerHTML = '';

        this.documents.forEach(doc => {
            const row = document.createElement('tr');
            row.className = 'fade-in-up';
            row.innerHTML = `
                <td>
                    <i class="fas fa-file-${this.getFileIcon(doc.file_type)} me-2"></i>
                    ${doc.original_filename}
                </td>
                <td>${this.formatFileSize(doc.file_size)}</td>
                <td>${this.formatDate(doc.upload_date)}</td>
                <td>${this.getStatusBadge(doc.scan_status)}</td>
                <td>${this.getSensitiveDataBadge(doc.has_sensitive_data, doc.sensitive_data_details)}</td>
                <td>
                    <div class="btn-group" role="group">
                        <button class="btn btn-sm btn-outline-primary" onclick="docManager.viewDocument('${doc._id}')" title="Xem chi tiết">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-success" onclick="docManager.downloadDocument('${doc._id}')" title="Tải xuống">
                            <i class="fas fa-download"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-info" onclick="docManager.shareDocument('${doc._id}')" title="Chia sẻ">
                            <i class="fas fa-share"></i>
                        </button>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    updateStatistics() {
        const total = this.documents.length;
        const sensitive = this.documents.filter(d => d.has_sensitive_data).length;
        const processing = this.documents.filter(d => d.scan_status === 'processing').length;
        const safe = this.documents.filter(d => d.scan_status === 'completed' && !d.has_sensitive_data).length;

        const elements = {
            totalDocs: total,
            sensitiveDocs: sensitive,
            processingDocs: processing,
            safeDocs: safe
        };

        Object.entries(elements).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                this.animateCounter(element, value);
            }
        });
    }

    animateCounter(element, targetValue) {
        const currentValue = parseInt(element.textContent) || 0;
        const increment = targetValue > currentValue ? 1 : -1;
        let current = currentValue;

        const timer = setInterval(() => {
            current += increment;
            element.textContent = current;

            if (current === targetValue) {
                clearInterval(timer);
                element.classList.add('pulse');
                setTimeout(() => element.classList.remove('pulse'), 1000);
            }
        }, 50);
    }

    getFileIcon(fileType) {
        if (fileType.includes('pdf')) return 'pdf';
        if (fileType.includes('word')) return 'word';
        return 'file';
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('vi-VN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    getStatusBadge(status) {
        const badges = {
            'pending': '<span class="badge bg-secondary"><i class="fas fa-clock me-1"></i>Chờ xử lý</span>',
            'processing': '<span class="badge bg-warning"><i class="fas fa-spinner fa-spin me-1"></i>Đang xử lý</span>',
            'completed': '<span class="badge bg-success"><i class="fas fa-check me-1"></i>Hoàn thành</span>',
            'failed': '<span class="badge bg-danger"><i class="fas fa-times me-1"></i>Thất bại</span>'
        };
        return badges[status] || '<span class="badge bg-secondary">Không xác định</span>';
    }

    getSensitiveDataBadge(hasSensitiveData, details) {
        if (!hasSensitiveData) {
            return '<span class="badge bg-success"><i class="fas fa-shield-alt me-1"></i>An toàn</span>';
        }
        return `<span class="badge bg-danger"><i class="fas fa-exclamation-triangle me-1"></i>${details.length} mục</span>`;
    }

    async viewDocument(documentId) {
        try {
            const response = await this.apiCall(`/api/documents/${documentId}`);
            if (response.ok) {
                const doc = await response.json();
                this.showDocumentModal(doc);
            }
        } catch (error) {
            console.error('Error viewing document:', error);
            this.showAlert('Lỗi khi xem tài liệu!', 'danger');
        }
    }

    showDocumentModal(doc) {
        const modalTitle = document.getElementById('documentModalTitle');
        const modalBody = document.getElementById('documentModalBody');

        if (modalTitle) modalTitle.textContent = doc.original_filename;

        let bodyContent = `
            <div class="row mb-3">
                <div class="col-md-6">
                    <h6><i class="fas fa-info-circle me-2"></i>Thông tin file</h6>
                    <ul class="list-unstyled">
                        <li><strong>Tên file:</strong> ${doc.original_filename}</li>
                        <li><strong>Kích thước:</strong> ${this.formatFileSize(doc.file_size)}</li>
                        <li><strong>Loại file:</strong> ${doc.file_type}</li>
                        <li><strong>Ngày upload:</strong> ${this.formatDate(doc.upload_date)}</li>
                        <li><strong>Trạng thái:</strong> ${this.getStatusBadge(doc.scan_status)}</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h6><i class="fas fa-shield-alt me-2"></i>Tình trạng bảo mật</h6>
                    <p>${this.getSensitiveDataBadge(doc.has_sensitive_data, doc.sensitive_data_details)}</p>
                </div>
            </div>
        `;

        if (doc.has_sensitive_data && doc.sensitive_data_details.length > 0) {
            bodyContent += `
                <div class="sensitive-data-warning">
                    <h6><i class="fas fa-exclamation-triangle text-warning me-2"></i>Thông tin nhạy cảm được phát hiện:</h6>
                    <div class="list-group">
            `;

            doc.sensitive_data_details.forEach(item => {
                bodyContent += `
                    <div class="list-group-item">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1">${item.description || item.type}</h6>
                            <small class="text-muted">${item.category}</small>
                        </div>
                        <p class="mb-1"><code class="sensitive-highlight">${item.value}</code></p>
                        ${item.confidence ? `<small class="text-muted">Độ tin cậy: ${Math.round(item.confidence * 100)}%</small>` : ''}
                    </div>
                `;
            });

            bodyContent += '</div></div>';
        }

        if (modalBody) modalBody.innerHTML = bodyContent;

        // Setup modal buttons
        const downloadBtn = document.getElementById('downloadBtn');
        const shareBtn = document.getElementById('shareBtn');

        if (downloadBtn) {
            downloadBtn.onclick = () => this.downloadDocument(doc._id);
        }

        if (shareBtn) {
            shareBtn.onclick = () => this.shareDocument(doc._id);
        }

        const modal = new bootstrap.Modal(document.getElementById('documentModal'));
        modal.show();
    }

    async downloadDocument(documentId) {
        try {
            const response = await fetch(`/api/documents/${documentId}/download`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = response.headers.get('Content-Disposition')?.split('filename=')[1] || 'document';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                this.showAlert('Tải xuống thành công!', 'success');
            } else {
                throw new Error('Download failed');
            }
        } catch (error) {
            console.error('Error downloading document:', error);
            this.showAlert('Lỗi khi tải xuống tài liệu!', 'danger');
        }
    }

    shareDocument(documentId) {
        this.currentDocumentId = documentId;
        const shareModal = new bootstrap.Modal(document.getElementById('shareModal'));
        shareModal.show();
    }

    async submitShare() {
        const emails = document.getElementById('shareEmails').value
            .split(',')
            .map(email => email.trim())
            .filter(email => email);

        if (emails.length === 0) {
            this.showAlert('Vui lòng nhập ít nhất một email!', 'warning');
            return;
        }

        try {
            const response = await this.apiCall(`/api/documents/${this.currentDocumentId}/share`, {
                method: 'POST',
                body: JSON.stringify(emails)
            });

            if (response.ok) {
                const result = await response.json();
                this.showAlert(`Đã chia sẻ thành công với ${result.shared_with_count} người dùng!`, 'success');
                
                const shareModal = bootstrap.Modal.getInstance(document.getElementById('shareModal'));
                shareModal.hide();
                document.getElementById('shareEmails').value = '';
            } else {
                throw new Error('Share failed');
            }
        } catch (error) {
            console.error('Error sharing document:', error);
            this.showAlert('Lỗi khi chia sẻ tài liệu!', 'danger');
        }
    }

    setupEventListeners() {
        // Upload functionality
        const uploadZone = document.getElementById('uploadZone');
        const fileInput = document.getElementById('fileInput');

        if (uploadZone && fileInput) {
            uploadZone.addEventListener('click', () => fileInput.click());

            uploadZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadZone.classList.add('dragover');
            });

            uploadZone.addEventListener('dragleave', () => {
                uploadZone.classList.remove('dragover');
            });

            uploadZone.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadZone.classList.remove('dragover');
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    this.handleFileUpload(files[0]);
                }
            });

            fileInput.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    this.handleFileUpload(e.target.files[0]);
                }
            });
        }

        // Auto-refresh documents
        if (this.isLoggedIn()) {
            setInterval(() => {
                this.loadDocuments();
            }, 10000); // Refresh every 10 seconds
        }
    }

    async handleFileUpload(file) {
        // Validate file type
        const allowedTypes = [
            'application/pdf', 
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ];
        
        if (!allowedTypes.includes(file.type)) {
            this.showAlert('Chỉ hỗ trợ file PDF và DOCX!', 'warning');
            return;
        }

        // Validate file size (10MB)
        if (file.size > 10 * 1024 * 1024) {
            this.showAlert('File quá lớn! Tối đa 10MB.', 'warning');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);

        // Show progress
        const uploadProgress = document.getElementById('uploadProgress');
        const progressBar = document.querySelector('.progress-bar');
        const uploadStatus = document.getElementById('uploadStatus');

        if (uploadProgress) uploadProgress.style.display = 'block';

        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`
                },
                body: formData
            });

            if (response.ok) {
                const result = await response.json();
                if (uploadStatus) uploadStatus.textContent = 'Upload thành công!';
                if (progressBar) {
                    progressBar.style.width = '100%';
                    progressBar.classList.add('bg-success');
                }
                
                this.showAlert('Upload thành công! Tài liệu đang được xử lý.', 'success');
                
                setTimeout(() => {
                    if (uploadProgress) uploadProgress.style.display = 'none';
                    if (progressBar) {
                        progressBar.style.width = '0%';
                        progressBar.classList.remove('bg-success');
                    }
                    this.loadDocuments();
                }, 2000);
            } else {
                const error = await response.json();
                throw new Error(error.detail || 'Upload failed');
            }
        } catch (error) {
            if (uploadStatus) uploadStatus.textContent = 'Upload thất bại: ' + error.message;
            if (progressBar) progressBar.classList.add('bg-danger');
            this.showAlert('Upload thất bại: ' + error.message, 'danger');
        }
    }

    showAlert(message, type = 'info') {
        const alertContainer = document.getElementById('alertContainer') || document.body;
        
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        alertContainer.appendChild(alertDiv);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.parentNode.removeChild(alertDiv);
            }
        }, 5000);
    }
}

// Initialize document manager when DOM is loaded
let docManager;
document.addEventListener('DOMContentLoaded', function() {
    docManager = new DocumentManager();
});

// Global functions for template usage
function logout() {
    if (docManager) {
        docManager.logout();
    }
}