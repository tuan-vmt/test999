#!/bin/bash

echo "🚀 Installing Document Management System with AI Sensitive Data Detection"

# Check if Python 3.8+ is installed
python_version=$(python3 --version 2>&1 | awk '{print $2}')
required_version="3.8"

if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

echo "✓ Python version: $python_version"

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not installed. Please install pip3."
    exit 1
fi

echo "✓ pip3 is available"

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv venv

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "⬆️ Upgrading pip..."
pip install --upgrade pip

# Install requirements
echo "📚 Installing Python dependencies..."
pip install -r requirements.txt

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p uploads templates static logs

# Copy environment template
if [ ! -f ".env" ]; then
    echo "📝 Creating .env file..."
    cat > .env << EOL
SECRET_KEY=your-super-secret-key-change-this-in-production-$(openssl rand -base64 32)
MONGODB_URL=mongodb://localhost:27017
DATABASE_NAME=document_management
OPENAI_API_KEY=your-openai-api-key-here
MAX_FILE_SIZE=10485760
UPLOAD_DIR=uploads
EOL
    echo "⚠️ Please update the .env file with your actual OpenAI API key"
fi

# Check if MongoDB is running
if command -v mongod &> /dev/null; then
    if pgrep mongod > /dev/null; then
        echo "✓ MongoDB is running"
    else
        echo "⚠️ MongoDB is installed but not running. Please start MongoDB:"
        echo "   sudo systemctl start mongod"
        echo "   or"
        echo "   brew services start mongodb/brew/mongodb-community"
    fi
else
    echo "⚠️ MongoDB is not installed. Please install MongoDB:"
    echo "   Ubuntu/Debian: sudo apt-get install mongodb"
    echo "   CentOS/RHEL: sudo yum install mongodb"
    echo "   macOS: brew install mongodb/brew/mongodb-community"
fi

echo ""
echo "🎉 Installation completed!"
echo ""
echo "📋 Next steps:"
echo "1. Update your OpenAI API key in the .env file"
echo "2. Make sure MongoDB is running"
echo "3. Run the application:"
echo "   source venv/bin/activate"
echo "   python run.py"
echo ""
echo "4. Open your browser and go to: http://localhost:8000"
echo ""
echo "📚 For more information, see the README.md file"