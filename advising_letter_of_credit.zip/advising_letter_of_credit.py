# Author: MrThanh - thanhbg.tnut@gmail.com/thanhnv8@mbbank.com.vn
# Created at: 11:21 AM 5/27/2025
import datetime

from app.src.base.advising_lc_code import Matched, Type, mapping_case_final
from app.src.entity.v1.compliance_entity import OverallResponse, Detail, Input
from app.src.integration.openai_integration import parse
from app.src.utils.advising_lc_utils import load_json_gpt
from app.src.integration.proxy_integration import DocumentClassificationRequest, DocumentClassification, \
    ProxyIntegration, StateMessage, DocumentExtract, DocumentExtractRequest

now = datetime.datetime.now()
current_date = now.strftime("%d/%m/%Y")


def preprocess_delivery_item_details(self, request_data, rule, business_entity):
    contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
        0].model_dump().get('metadata')
    goods_services = contract_data.get('f45A_goods_services', {})
    goods_services_metadata = goods_services.get('metadata', {})
    if not goods_services_metadata:
        commodity_name = unit_price = total_amount = total_amount_tolerance = quantity_tolerance = ''

    else:
        commodity = goods_services_metadata.get('bct_45a_desc_goods', {})
        if not commodity:
            commodity_name = unit_price = ''
        else:
            commodity_name = [c.get('bct_45a_commodity') for c in commodity]
            unit_price = [c.get('bct_45a_uprice_amount') + ' ' + c.get('bct_45a_uprice_currency') + '/' + c.get(
                'bct_45a_uprice_unit') for c in commodity]

        total_amount = goods_services_metadata.get('bct_45a_total_amount_value',
                                                   '') + ' ' + goods_services_metadata.get(
            'bct_45a_total_amount_currency', '')
        total_amount_tolerance = goods_services_metadata.get('bct_45a_total_amount_incre_tolerance', '')
        quantity_tolerance = goods_services_metadata.get('bct_45a_total_quantity_incre_tolerance', '')

    messages = []
    for prompt in rule.messages[0].prompt:
        messages.append(prompt.dict())

    if len(messages) > 1:
        messages[1]['content'] = messages[1]['content'].format(
            commodity_name=commodity_name,
            unit_price=unit_price,
            total_amount=total_amount,
            total_amount_tolerance=total_amount_tolerance,
            quantity_tolerance=quantity_tolerance
        )

    field_values = {
        "commodity_name": str(commodity_name),
        "unit_price": str(unit_price),
        "total_amount": total_amount,
        "total_amount_tolerance": total_amount_tolerance,
        "quantity_tolerance": quantity_tolerance
    }

    return messages, field_values


def preprocess_delivery_quality_origin_quantity(self, request_data, rule, business_entity):
    contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
        0].model_dump().get('metadata')
    goods_services = contract_data.get('f45A_goods_services', {})
    goods_services_metadata = goods_services.get('metadata', {})

    if not goods_services_metadata:
        origin = quality = quantity_value = ''

    else:
        quality = goods_services_metadata.get('bct_45a_quality')
        origin = goods_services_metadata.get('bct_45a_origin')

        commodity = goods_services_metadata.get('bct_45a_desc_goods', {})
        if not commodity:
            quantity_value = ''
        else:
            quantity_value = [c.get('bct_45a_quantity_value') + ' ' + c.get('bct_45a_quantity_unit') for c in
                              commodity]

    messages = []
    for prompt in rule.messages[0].prompt:
        messages.append(prompt.dict())

    if len(messages) > 1:
        messages[1]['content'] = messages[1]['content'].format(
            quality=quality,
            origin=origin,
            quantity_value=quantity_value
        )

    field_values = {
        "quality": quality or '',
        "origin": origin or '',
        "quantity_value": str(quantity_value)
    }

    return messages, field_values


def preprocess_delivery_incoterms_version(self, request_data, rule, business_entity):
    contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
        0].model_dump().get('metadata')
    goods_services = contract_data.get('f45A_goods_services', {})
    goods_services_metadata = goods_services.get('metadata', {})
    if not goods_services_metadata:
        trade_term = incoterm = ''
    else:
        trade_term = goods_services_metadata.get('bct_45a_trade_term')
        incoterm = goods_services_metadata.get('bct_45a_incoterm')

    messages = []
    for prompt in rule.messages[0].prompt:
        messages.append(prompt.dict())

    if len(messages) > 1:
        messages[1]['content'] = messages[1]['content'].format(
            trade_term=trade_term,
            incoterm=incoterm
        )

    field_values = {
        "trade_term": trade_term or '',
        "incoterm": incoterm or ''
    }

    return messages, field_values


def preprocess_delivery_time_specified(self, request_data, rule, business_entity):
    contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
        0].model_dump().get('metadata')
    latest_date_of_ship = contract_data.get('f44C_latest_date_of_ship', {}).get('value')
    shipment_period = contract_data.get('f44D_shipment_period', {}).get('value')

    messages = []
    for prompt in rule.messages[0].prompt:
        messages.append(prompt.dict())

    if len(messages) > 1:
        messages[1]['content'] = messages[1]['content'].format(
            latest_date_of_ship=latest_date_of_ship,
            shipment_period=shipment_period
        )

    field_values = {
        "latest_date_of_ship": latest_date_of_ship or '',
        "shipment_period": shipment_period or ''
    }

    return messages, field_values


def preprocess_delivery_location_specified(self, request_data, rule, business_entity):
    contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
        0].model_dump().get('metadata')

    place_of_receipt = contract_data.get('f44A_place_of_receipt', {}).get('value')
    port_of_loading = contract_data.get('port_of_loading', {}).get('value')
    airport_of_departure = contract_data.get('airport_of_departure', {}).get('value')
    port_of_discharge = contract_data.get('port_of_discharge', {}).get('value')
    airport_of_destination = contract_data.get('airport_of_destination', {}).get('value')
    place_of_final_dest = contract_data.get('f44B_place_of_final_dest', {}).get('value')

    goods_services = contract_data.get('f45A_goods_services', {})
    goods_services_metadata = goods_services.get('metadata', {})
    if not goods_services_metadata:
        trade_term = ''
        incoterm = ''
    else:
        trade_term = goods_services_metadata.get('bct_45a_trade_term', '')
        incoterm = goods_services_metadata.get('bct_45a_incoterm', '')

    messages = []
    for prompt in rule.messages[0].prompt:
        messages.append(prompt.dict())

    if len(messages) > 1:
        messages[1]['content'] = messages[1]['content'].format(
            place_of_receipt=place_of_receipt,
            port_of_loading=port_of_loading,
            airport_of_departure=airport_of_departure,
            port_of_discharge=port_of_discharge,
            airport_of_destination=airport_of_destination,
            place_of_final_dest=place_of_final_dest,
            trade_term=trade_term,
            incoterm=incoterm
        )

    field_values = {
        "place_of_receipt": place_of_receipt or '',
        "port_of_loading": port_of_loading or '',
        "airport_of_departure": airport_of_departure or '',
        "port_of_discharge": port_of_discharge or '',
        "airport_of_destination": airport_of_destination or '',
        "place_of_final_dest": place_of_final_dest or '',
        "trade_term": trade_term,
        "incoterm": incoterm
    }

    return messages, field_values


def preprocess_delivery_partial_allowed(self, request_data, rule, business_entity):
    contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
        0].model_dump().get('metadata')

    partial_shipment = contract_data.get('partial_shipment', {}).get('value')

    messages = []
    for prompt in rule.messages[0].prompt:
        messages.append(prompt.dict())

    if len(messages) > 1:
        messages[1]['content'] = messages[1]['content'].format(
            partial_shipment=partial_shipment,
        )

    field_values = {
        "partial_shipment": partial_shipment or ''
    }

    return messages, field_values


def preprocess_delivery_transshipment_allowed(self, request_data, rule, business_entity):
    contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
        0].model_dump().get('metadata')
    transhipment = contract_data.get('transhipment', {}).get('value')

    messages = []
    for prompt in rule.messages[0].prompt:
        messages.append(prompt.dict())

    if len(messages) > 1:
        messages[1]['content'] = messages[1]['content'].format(
            transhipment=transhipment,
        )

    field_values = {
        "transhipment": transhipment or ''
    }

    return messages, field_values


def preprocess_payment_lc_method_multiple_terms(self, request_data, rule, business_entity):
    contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
        0].model_dump().get('metadata')
    payment = contract_data.get('payment', {}).get('value')

    messages = []
    for prompt in rule.messages[0].prompt:
        messages.append(prompt.dict())

    if len(messages) > 1:
        messages[1]['content'] = messages[1]['content'].format(
            payment=payment,
        )

    field_values = {
        "payment": payment or ''
    }

    return messages, field_values


def preprocess_payment_lc_type_documents_bank(self, request_data, rule, business_entity):
    contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
        0].model_dump().get('metadata')
    tenor = contract_data.get('tenor', {}).get('value', '')
    try:
        trade_term = contract_data.get(f'f45A_goods_services', {}).get('metadata', {}).get('bct_45a_trade_term', '')
    except:
        trade_term = ''
    documents_required = contract_data.get(f'f46A_documents_requires', {}).get('value', '')
    advise_bank = contract_data.get(f'advise_bank', {}).get('value', '')

    # multiple prompts
    all_messages = []
    for message in rule.messages:
        messages = []
        for prompt in message.prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                tenor=tenor,
                trade_term=trade_term,
                documents_required=documents_required,
                advise_bank=advise_bank
            )

        all_messages.append(messages)

    field_values = {
        "tenor": tenor,
        "trade_term": trade_term,
        "documents_required": documents_required,
        "advise_bank": advise_bank
    }

    return all_messages, field_values


class AdvisingLetterOfCredit:
    def __init__(self,
                 proxy_integration: ProxyIntegration):
        self.proxy_integration = proxy_integration

        self.contract_document_code = 'lcnk_contract'
        self.annex_document_code = 'lcnk_annex'
        self.lc_document_code = 'lcnk_lc'

        self.bct_other_document_code = 'other'
        self.bct_other_document_name = 'Tài liệu khác'
        self.bct_other_group_code = 'other'
        self.bct_other_group_name = 'Nhóm tài liệu khác'

        self.copy_warning = "Hợp đồng chưa có giá trị hiệu lực, thiếu con dấu thẩm quyền và giáp lai của các bên liên quan. Kính đề nghị Quý khách hàng cung cấp bản gốc/sao y bản chính hợp đồng, đóng dấu giáp lai, có đầy đủ chữ ký và con dấu của 2 bên người mua và người bán trước khi phát hành LC chính thức"
        self.two_pages_org_warning = "Đề nghị kiểm tra hợp đồng có in 2 mặt không"

    async def post_process_classify(self, request_data, rules, business_entity):
        preprocess_rules = [rule for rule in rules if rule.group_code == 'PREPROCESS']
        if len(preprocess_rules) != 1:
            return request_data
        preprocess_rule = preprocess_rules[0]

        documents_data = request_data[0].documents
        flow_code_data = request_data[0].model_dump()
        preprocessed_data = []

        document_codes = [d.document_code for d in documents_data]
        count_contract = sum([1 for d in document_codes if d == self.contract_document_code])
        count_annex = sum([1 for d in document_codes if d == self.annex_document_code])
        count_lc = sum([1 for d in document_codes if d == self.lc_document_code])

        if count_contract > 1:
            message = 'NHIỀU HƠN 1 HỢP ĐỒNG'
            responses = [OverallResponse(
                rule_name=rule.rule_name,
                rule_code=rule.rule_code,
                group_name=rule.group_name,
                group_code=rule.group_code,
                correct=False,
                soa_code='AI_OCR_0001',
                soa_desc=message,
                comment=message,
                matched='ERROR',
            ) for rule in rules]
            return responses

        elif count_contract == 1:
            contract_data = [d for d in documents_data if d.document_code == self.contract_document_code][0]

            if count_annex >= 1:
                annex_datas = [d for d in documents_data if d.document_code == self.annex_document_code]

                contract_date_origin = contract_data.metadata.get('contract_date', {}).get('value', '')
                contract_no_origin = contract_data.metadata.get('contract_no', {}).get('value', '')

                contract_date_annex = []
                contract_no_annex = []
                annex_date_annex = []

                for annex_data in annex_datas:
                    contract_date_annex.append(annex_data.metadata.get('contract_date', {}).get('value', ''))
                    contract_no_annex.append(annex_data.metadata.get('contract_no', {}).get('value', ''))
                    annex_date_annex.append(annex_data.metadata.get('annex_date', {}).get('value', ''))

                messages = []
                for prompt in preprocess_rule.messages[0].prompt:
                    messages.append(prompt.dict())

                if len(messages) > 1:
                    messages[1]['content'] = messages[1]['content'].format(contract_date_origin=contract_date_origin,
                                                                           contract_no_origin=contract_no_origin,
                                                                           contract_date_annex=contract_date_annex,
                                                                           contract_no_annex=contract_no_annex,
                                                                           annex_date_annex=annex_date_annex)

                response = parse(messages=messages,
                                 base_url=business_entity.openai.base_url,
                                 api_version=business_entity.openai.api_version,
                                 api_key=business_entity.openai.api_key,
                                 temperature=0,
                                 top_p=None,
                                 client_message_id=flow_code_data.get("flow_code"))

                response_text = response.choices[0].message.content.strip()

                annex_index = load_json_gpt(response_text).get('annex_index')

                # UPDATE BACK TO PROXY
                for i, annex_data in enumerate(annex_datas):
                    if i + 1 not in annex_index:
                        contract_data_classification = DocumentClassification.model_validate(contract_data.dict())
                        annex_document_classification = DocumentClassification.model_validate(annex_data.dict())
                        annex_document_classification.group_code = self.bct_other_group_code
                        annex_document_classification.group_name = self.bct_other_group_name

                        contract_data_extraction = DocumentExtract.model_validate(contract_data.dict())
                        annex_document_extraction = DocumentExtract.model_validate(annex_data.dict())
                        annex_document_extraction.group_code = self.bct_other_group_code
                        annex_document_extraction.group_name = self.bct_other_group_name

                        classification_document_request = [annex_document_classification]
                        extraction_document_request = [annex_document_extraction]
                        if annex_data.file_info.get('doc_id') == contract_data.file_info.get('doc_id'):
                            classification_document_request.append(contract_data_classification)
                            extraction_document_request.append(contract_data_extraction)

                        classification_request = DocumentClassificationRequest(
                            documents=classification_document_request,
                            status=StateMessage.SUCCESS)

                        self.proxy_integration.update_classification_result(
                            document_classification_request=classification_request,
                            business_code=request_data[0].business_code,
                            request_id=request_data[0].request_id,
                            doc_id=annex_data.file_info.get('doc_id'),
                            client_message_id=request_data[0].request_id
                            )

                        extraction_request = DocumentExtractRequest(documents=extraction_document_request,
                                                                    status=StateMessage.SUCCESS)

                        self.proxy_integration.update_extraction_result(document_extract_request=extraction_request,
                                                                        business_code=request_data[0].business_code,
                                                                        request_id=request_data[0].request_id,
                                                                        doc_id=annex_data.file_info.get('doc_id'),
                                                                        client_message_id=request_data[0].request_id
                                                                        )

                if len(annex_index) == 0:
                    annex_data = None
                elif len(annex_index) == 1:
                    annex_data = annex_datas[annex_index[0] - 1]
                else:
                    message = 'NHIỀU HƠN 1 PHỤ LỤC KHỚP HỢP ĐỒNG'
                    responses = [OverallResponse(
                        rule_name=rule.rule_name,
                        rule_code=rule.rule_code,
                        group_name=rule.group_name,
                        group_code=rule.group_code,
                        correct=False,
                        soa_code='AI_OCR_0001',
                        soa_desc=message,
                        comment=message,
                        matched='ERROR',
                    ) for rule in rules]
                    return responses

                # merge contract vs annex
                if annex_data:
                    for key, value in contract_data.metadata.items():
                        contract_field_value = value.get('value')
                        annex_field_value = annex_data.metadata.get(key, {}).get('value')
                        annex_field_metadata = annex_data.metadata.get(key, {}).get('metadata')

                        if annex_field_value and not annex_field_metadata:
                            contract_data.metadata[key] = annex_data.metadata.get(key)

                        elif annex_field_value and annex_field_metadata:
                            for k, v in annex_field_metadata.items():
                                if v:
                                    contract_data.metadata[key]['metadata'][k] = v
            preprocessed_data.append(contract_data)

        else:
            contract_data = None
            message = 'KHÔNG CÓ HỢP ĐỒNG'
            responses = [OverallResponse(
                rule_name=rule.rule_name,
                rule_code=rule.rule_code,
                group_name=rule.group_name,
                group_code=rule.group_code,
                correct=False,
                soa_code='AI_OCR_0001',
                soa_desc=message,
                comment=message,
                matched='ERROR',
            ) for rule in rules]
            return responses

        if count_lc == 1:
            lc_data = [d for d in documents_data if d.document_code == self.lc_document_code][0]
            preprocessed_data.append(lc_data)
        elif count_lc == 0:
            lc_data = None
        else:
            message = 'NHIỀU HƠN 1 LC'
            response = OverallResponse(
                correct=False,
                soa_code='AI_OCR_0001',
                soa_desc=message,
                comment=message,
                matched='ERROR',
            )
            return response

        request_data[0].documents = preprocessed_data
        return request_data

    def get_responses(self, request_data):
        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get(
            'pages')
        metadata_list = []
        for doc in contract_data:
            metadata_list.append(doc.get('metadata'))

        return metadata_list
    
    def fill_input_values(self, rule_inputs, field_values):
        inputs_with_values = []
        for input_item in rule_inputs:
            input_dict = input_item.dict()
            field_code = input_dict.get('field_code', '')
            
            if field_code in field_values:
                input_dict['value'] = field_values[field_code]
            else:
                input_dict['value'] = ""
                
            inputs_with_values.append(Input.parse_obj(input_dict))
        
        return inputs_with_values

    @staticmethod
    def parse_page(response):
        data = response.get("data", {})
        # Chữ ký
        signatures = data.get("signature", {}).get("value", {}).get("is_signature", {}).get("value", [])
        sig_colors = data.get("signature", {}).get("value", {}).get("is_color", {}).get("value", [])

        # Dấu tròn (bao gồm giáp lai)
        circle_colors = data.get("circle_stamp", {}).get("value", {}).get("is_color", {}).get("value", [])
        affixed_flags = data.get("circle_stamp", {}).get("value", {}).get("is_affixed_seal", {}).get("value", [])
        circle_stamps = [not b for b in affixed_flags]

        # Dấu sao y
        square_stamps = data.get("square_stamp", {}).get("value", {})
        has_sao_y = len(square_stamps.get("is_true_asterisk", {}).get("value", [])) > 0
        sao_y_date = len(square_stamps.get("is_datetime", {}).get("value", [])) > 0

        return {
            "signature_count": len(signatures),
            "circle_stamp_red": any(stamp and color for stamp, color in zip(circle_stamps, circle_colors)),
            "circle_affixed_red": any(aff and color for aff, color in zip(affixed_flags, circle_colors)),
            "circle_affixed_black": any(aff and not color for aff, color in zip(affixed_flags, circle_colors)),
            "sao_y": has_sao_y,
            "sao_y_valid": sao_y_date,
            "has_signature": len(signatures) > 0,
        }

    def is_original(self, pages):
        n_pages = len(pages)
        # 1 trang
        if n_pages == 1:
            page = pages[0]
            check = (
                    page["circle_stamp_red"]
                    and page["has_signature"]
                    and not page["circle_affixed_red"]
            )
            return check, "" if check else self.copy_warning, check
        elif n_pages == 2:  # >=2 trang
            has_signature = any(p["has_signature"] and p["circle_stamp_red"] for p in pages)
            affixed_black = any(p["circle_affixed_black"] for p in pages)

            affixed_pages = [i for i, p in enumerate(pages) if p["circle_affixed_red"]]
            full_page = [i for i in range(len(pages))]
            odd_page = full_page[::2]
            even_page = full_page[1::2]

            affixed_ok = (affixed_pages == full_page or affixed_pages == odd_page or affixed_pages == even_page)
            check = has_signature and not affixed_black
            if not check:
                return check, self.copy_warning, check
            elif not affixed_ok:
                return check, self.two_pages_org_warning, not check
            else:
                return check, "", check
            # return check, "" if check else self.two_pages_org_warning
        else:  # >=2 trang
            has_signature = any(p["has_signature"] and p["circle_stamp_red"] for p in pages)
            affixed_pages = [i for i, p in enumerate(pages) if p["circle_affixed_red"]]
            full_page = [i for i in range(len(pages))]
            odd_page = full_page[::2]
            even_page = full_page[1::2]

            affixed_ok = (affixed_pages == full_page or affixed_pages == odd_page or affixed_pages == even_page)
            affixed_black = any(p["circle_affixed_black"] for p in pages)
            check = has_signature and affixed_ok and not affixed_black
            if check:
                if affixed_pages == full_page:
                    return check, "", check
                return check, self.two_pages_org_warning, not check
            else:
                return check, self.copy_warning, check
            # return check, "" if check else self.copy_warning, check

    def is_certified_copy(self, pages):
        # if n_pages == 1:
        #
        # if n_pages == 2:

        sao_y_pages = [p for p in pages if p["sao_y"]]
        continue_check = True
        if not sao_y_pages:
            return False, continue_check, self.copy_warning, ""
        continue_check = False
        has_invalid_sao_y = any(p["sao_y"] and not p["sao_y_valid"] for p in pages)

        same_page_sigs = any(p["has_signature"] and p["circle_stamp_red"] for p in sao_y_pages)
        affixed_pages = [i for i, p in enumerate(pages) if p["circle_affixed_red"]]
        full_page = [i for i in range(len(pages))]
        odd_page = full_page[::2]
        even_page = full_page[1::2]

        affixed_ok = (affixed_pages == full_page or affixed_pages == odd_page or affixed_pages == even_page)
        affixed_black = any(p["circle_affixed_black"] for p in pages)

        is_valid = (
                all(p["sao_y_valid"] for p in sao_y_pages) and
                same_page_sigs and
                affixed_ok and
                affixed_black
        )
        if is_valid:
            return True, not continue_check, "", True
        else:
            if has_invalid_sao_y:
                return False, not continue_check, self.copy_warning, False
            if not same_page_sigs:
                return False, continue_check, self.copy_warning, False
            if not affixed_black:
                return False, continue_check, self.copy_warning, False
            return False, continue_check, self.copy_warning, False

    @staticmethod
    def transform_response(response, document_code="lcnk_contract", document_name="Foreign Trade Contract"):
        result = []

        for field_code, field_data in response.items():
            if field_data['datatype'] != 'OBJECT':
                continue

            if field_code == "signature":
                sub_field = field_data['value'].get("is_signature", {})
                value_list = sub_field.get('value', [])
                conf_list = sub_field.get('conf', [])
                box_list = sub_field.get('box', [])
                datatype = sub_field.get('datatype', None)

                for idx, val in enumerate(value_list):
                    item = Input(
                        placeholder="",
                        field_name="Chữ ký",
                        field_code="is_signature",
                        flow_code="",
                        code="",
                        value={
                            "index": idx,
                            "value": "Chữ ký",
                            "conf": conf_list[idx] if idx < len(conf_list) else None,
                            "box": box_list[idx] if idx < len(box_list) else None,
                            "polygon": sub_field.get("polygon", [None])[idx] if idx < len(
                                sub_field.get("polygon", [])) else None,
                            "datatype": datatype,
                            "description": "Chữ ký",
                            "title": None,
                            "metadata": None,
                            "origin_document": ""
                        },
                        document_code=document_code,
                        document_name=document_name,
                        description="Chữ ký"
                    )
                    result.append(Detail(inputs=[item], conclusion=True, comment=""))

            elif field_code == "circle_stamp":
                sub_field = field_data['value'].get("is_affixed_seal", {})
                value_list = sub_field.get('value', [])
                conf_list = sub_field.get('conf', [])
                box_list = sub_field.get('box', [])
                datatype = sub_field.get('datatype', None)

                for idx, val in enumerate(value_list):
                    field_name = "Giáp lai" if val else "Dấu tròn"
                    item = Input(
                        placeholder="",
                        field_name=field_name,
                        field_code="is_affixed_seal",
                        flow_code="",
                        code="",
                        value={
                            "index": idx,
                            "value": field_name,
                            "conf": conf_list[idx] if idx < len(conf_list) else None,
                            "box": box_list[idx] if idx < len(box_list) else None,
                            "polygon": sub_field.get("polygon", [None])[idx] if idx < len(
                                sub_field.get("polygon", [])) else None,
                            "datatype": datatype,
                            "description": field_name,
                            "title": None,
                            "metadata": None,
                            "origin_document": ""
                        },
                        document_code=document_code,
                        document_name=document_name,
                        description=field_name
                    )
                    result.append(Detail(inputs=[item]))

            elif field_code == "square_stamp":
                sub_field = field_data['value'].get("is_true_asterisk", {})
                value_list = sub_field.get('value', [])
                conf_list = sub_field.get('conf', [])
                box_list = sub_field.get('box', [])
                datatype = sub_field.get('datatype', None)

                for idx, val in enumerate(value_list):
                    item = Input(
                        placeholder="",
                        field_name="Dấu sao y",
                        field_code="is_true_asterisk",
                        flow_code="",
                        code="",
                        value={
                            "index": idx,
                            "value": "Dấu sao y",
                            "conf": conf_list[idx] if idx < len(conf_list) else None,
                            "box": box_list[idx] if idx < len(box_list) else None,
                            "polygon": sub_field.get("polygon", [None])[idx] if idx < len(
                                sub_field.get("polygon", [])) else None,
                            "datatype": datatype,
                            "description": "Dấu sao y",
                            "title": None,
                            "metadata": None,
                            "origin_document": ""
                        },
                        document_code=document_code,
                        document_name=document_name,
                        description="Dấu sao y"
                    )
                    result.append(Detail(inputs=[item]))

        return result

    async def check_contract_compliance_value(self, request_data, rule, business_entity):
        response_list = self.get_responses(request_data)

        # === Phân tích từng trang
        pages = [self.parse_page(res) for res in response_list]
        list_details = []
        for doc in response_list:
            list_details.extend(self.transform_response(doc))
        is_original, reason, check_valid = self.is_original(pages)

        is_sao_y, _continue_check, reason_sao_y, check_valid_y = self.is_certified_copy(pages)
        # _continue_check = True
        # is_sao_y = False
        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc="",
            comment="",
            matched=Matched.ERROR,
            type=Type.COMPLIANCE,
            details=list_details,
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        if is_sao_y:
            response.soa_desc = reason_sao_y  # câu cảnh báo
            response.matched = Matched.SUCCESS if check_valid_y else Matched.ERROR  # thoa man/khong thoa man
            # response.comment = "SAO Y"
            return response
        if _continue_check:
            if is_original:
                response.soa_desc = reason  # câu cảnh báo
                response.matched = Matched.SUCCESS if check_valid else Matched.ERROR  # thoa man/khong thoa man
                # response.comment = "BẢN GỐC"
                return response
            else:
                response.soa_desc = self.copy_warning  # câu cảnh báo
                response.matched = Matched.SUCCESS if check_valid else Matched.ERROR  # thoa man/khong thoa man
                # response.comment = "BẢN COPY"
                return response
        else:
            response.soa_desc = self.copy_warning  # câu cảnh báo
            response.matched = Matched.SUCCESS if check_valid else Matched.ERROR  # thoa man/khong thoa man
            # response.comment = "BẢN COPY"
            return response
            # return f"BẢN COPY", self.copy_warning, check_valid

    async def check_contract_legal_value(self, request_data, rule, business_entity):
        response_list = self.get_responses(request_data)

        # === Phân tích từng trang
        pages = [self.parse_page(res) for res in response_list]
        list_details = []
        for doc in response_list:
            list_details.extend(self.transform_response(doc))
        # list_details = [self.transform_response(doc) for doc in response_list]

        is_original, reason, check_valid = self.is_original(pages)

        is_sao_y, _continue_check, reason_sao_y, check_valid_y = self.is_certified_copy(pages)
        # _continue_check = True
        # is_sao_y = False
        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc="",
            comment="",
            matched=Matched.ERROR,
            type=Type.LEGAL,
            details=list_details,
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        if is_sao_y:
            response.soa_desc = ''  # câu cảnh báo
            response.matched = "CERTIFIED_COPY"
            return response
        if _continue_check:
            if is_original:
                response.soa_desc = ''  # câu cảnh báo
                response.matched = "ORIGINAL"
                return response
            else:
                response.soa_desc = ''  # câu cảnh báo
                response.matched = "COPY"
                return response
        else:
            response.soa_desc = ''  # câu cảnh báo
            response.matched = "COPY"
            return response
            # return f"BẢN COPY", self.copy_warning, check_valid

    async def check_delivery_item_details(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()
        client_message_id = request_data[0].model_dump().get('flow_code')

        messages, field_values = preprocess_delivery_item_details(self, request_data, rule, business_entity)

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=client_message_id)

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code, {}).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )

        return response

    async def check_delivery_quality_origin_quantity(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        messages, field_values = preprocess_delivery_quality_origin_quantity(self, request_data, rule, business_entity)

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code, {}).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_delivery_incoterms_version(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        messages, field_values = preprocess_delivery_incoterms_version(self, request_data, rule, business_entity)

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code, {}).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_delivery_time_specified(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        messages, field_values = preprocess_delivery_time_specified(self, request_data, rule, business_entity)

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code, {}).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_delivery_location_specified(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        messages, field_values = preprocess_delivery_location_specified(self, request_data, rule, business_entity)

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code, {}).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_delivery_partial_allowed(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        messages, field_values = preprocess_delivery_partial_allowed(self, request_data, rule, business_entity)

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code, {}).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_delivery_transshipment_allowed(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        messages, field_values = preprocess_delivery_transshipment_allowed(self, request_data, rule, business_entity)

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code, {}).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_payment_lc_method_multiple_terms(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()
        messages, field_values = preprocess_payment_lc_method_multiple_terms(self, request_data, rule, business_entity)

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code, {}).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_payment_lc_type_documents_bank(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        all_messages, field_values = preprocess_payment_lc_type_documents_bank(self, request_data, rule, business_entity)

        response_datas = []

        for messages in all_messages:
            response_gpt = parse(messages=messages,
                                base_url=business_entity.openai.base_url,
                                api_version=business_entity.openai.api_version,
                                api_key=business_entity.openai.api_key,
                                temperature=0,
                                top_p=None,
                                client_message_id=flow_code_data.get("flow_code"))

            response_text = response_gpt.choices[0].message.content.strip()
            response_data = load_json_gpt(response_text)
            response_datas.append(response_data)

        soa_desc = ''
        comment = ''
        matched = []

        for response_data in response_datas:
            if not response_data.get('is_compliance'):
                soa_desc += mapping_case_final.get(rule.rule_code, {}).get(response_data.get('case'), '') + ' '
            comment += response_data.get('explanation', '') + ' '
            matched.append(response_data.get('is_compliance'))

        matched_bool = all(matched)

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=soa_desc.strip(),
            comment=comment.strip(),
            matched=Matched.SUCCESS if matched_bool else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=matched_bool,
                answer=comment.strip()
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    # async def post_process_classify(self, request_data, rule, business_entity):
    #     documents_data = request_data[0].documents
    #     flow_code_data = request_data[0].model_dump()
    #     preprocessed_data = []
    #
    #     document_codes = [d.document_code for d in documents_data]
    #     count_contract = sum([1 for d in document_codes if d == self.contract_document_code])
    #     count_annex = sum([1 for d in document_codes if d == self.annex_document_code])
    #     count_lc = sum([1 for d in document_codes if d == self.lc_document_code])
    #
    #     if count_contract > 1:
    #         message = 'NHIỀU HƠN 1 HỢP ĐỒNG'
    #         response = OverallResponse(
    #             correct=False,
    #             soa_code='AI_OCR_0001',
    #             soa_desc=message,
    #             comment=message,
    #             matched='ERROR',
    #         )
    #         return response
    #
    #     elif count_contract == 1:
    #         contract_data = [d for d in documents_data if d.document_code == self.contract_document_code][0]
    #
    #         if count_annex >= 1:
    #             annex_datas = [d for d in documents_data if d.document_code == self.annex_document_code]
    #
    #             contract_date_origin = contract_data.metadata.get('contract_date', {}).get('value', '')
    #             contract_no_origin = contract_data.metadata.get('contract_no', {}).get('value', '')
    #
    #             contract_date_annex = []
    #             contract_no_annex = []
    #             annex_date_annex = []
    #
    #             for annex_data in annex_datas:
    #                 contract_date_annex.append(annex_data.metadata.get('contract_date', {}).get('value', ''))
    #                 contract_no_annex.append(annex_data.metadata.get('contract_no', {}).get('value', ''))
    #                 annex_date_annex.append(annex_data.metadata.get('annex_date', {}).get('value', ''))
    #
    #             messages = []
    #             for prompt in rule.messages[0].prompt:
    #                 messages.append(prompt.dict())
    #
    #             if len(messages) > 1:
    #                 messages[1]['content'] = messages[1]['content'].format(contract_date_origin=contract_date_origin,
    #                                                                        contract_no_origin=contract_no_origin,
    #                                                                        contract_date_annex=contract_date_annex,
    #                                                                        contract_no_annex=contract_no_annex,
    #                                                                        annex_date_annex=annex_date_annex)
    #
    #             response = parse(messages=messages,
    #                              base_url=business_entity.openai.base_url,
    #                              api_version=business_entity.openai.api_version,
    #                              api_key=business_entity.openai.api_key,
    #                              temperature=0,
    #                              top_p=None,
    #                              client_message_id=flow_code_data.get("flow_code"))
    #
    #             response_text = response.choices[0].message.content.strip()
    #
    #             annex_index = load_json_gpt(response_text).get('annex_index')
    #             if len(annex_index) == 0:
    #                 annex_data = None
    #             elif len(annex_index) == 1:
    #                 annex_data = annex_datas[annex_index[0] - 1]
    #             else:
    #                 message = 'NHIỀU HƠN 1 PHỤ LỤC MATCH HỢP ĐỒNG'
    #                 response = OverallResponse(
    #                     correct=False,
    #                     soa_code='AI_OCR_0001',
    #                     soa_desc=message,
    #                     comment=message,
    #                     matched='ERROR',
    #                 )
    #                 return response
    #
    #             # merge contract vs annex
    #             if annex_data:
    #                 for key, value in contract_data.metadata.items():
    #                     contract_field_value = value.get('value')
    #                     annex_field_value = annex_data.metadata.get(key, {}).get('value')
    #                     annex_field_metadata = annex_data.metadata.get(key, {}).get('metadata')
    #
    #                     if annex_field_value and not annex_field_metadata:
    #                         contract_data.metadata[key] = annex_data.metadata.get(key)
    #
    #                     elif annex_field_value and annex_field_metadata:
    #                         for k, v in annex_field_metadata.items():
    #                             if v:
    #                                 contract_data.metadata[key]['metadata'][k] = v
    #         preprocessed_data.append(contract_data)
    #
    #     else:
    #         contract_data = None
    #         message = 'Không tìm thấy hợp đồng'
    #         response = OverallResponse(
    #             correct=False,
    #             soa_code='AI_OCR_0001',
    #             soa_desc=message,
    #             comment=message,
    #             matched='ERROR',
    #         )
    #         return response
    #
    #     if count_lc == 1:
    #         lc_data = [d for d in documents_data if d.document_code == self.lc_document_code][0]
    #         preprocessed_data.append(lc_data)
    #     elif count_lc == 0:
    #         lc_data = None
    #         message = 'Không tìm thấy đơn mở L/C'
    #         response = OverallResponse(
    #             correct=False,
    #             soa_code='AI_OCR_0001',
    #             soa_desc=message,
    #             comment=message,
    #             matched='ERROR',
    #         )
    #         return response
    #     else:
    #         message = 'NHIỀU HƠN 1 LC'
    #         response = OverallResponse(
    #             correct=False,
    #             soa_code='AI_OCR_0001',
    #             soa_desc=message,
    #             comment=message,
    #             matched='ERROR',
    #         )
    #         return response
    #
    #     request_data[0].documents = preprocessed_data
    #
    #     return request_data

    async def check_contract_no_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()
        
        # Extract contract and LC data
        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]
        
        # self.contract_document_code = 'lcnk_contract'
        # self.lc_document_code = 'lcnk_lc'
        
        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        contract_number_lc = lc_data.get("lc_contract_no", {}).get('value', "")
        contract_number_contract = contract_data.get("contract_no", {}).get('value', "")

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                contract_number_lc=contract_number_lc,
                contract_number_contract=contract_number_contract
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "contract_number_lc": contract_number_lc,
            "contract_number_contract": contract_number_contract
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_contract_date_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_contract_date = lc_data.get('lc_contract_date', {}).get('value', '')
        contract_contract_date = contract_data.get('contract_date', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_contract_date=lc_contract_date,
                contract_contract_date=contract_contract_date
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_contract_date": lc_contract_date,
            "contract_contract_date": contract_contract_date
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_bank_information_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_1st_swift_code = lc_data.get('advise_bank_swiftcode', {}).get('value', '')
        lc_1st_bank_name = lc_data.get('advise_bank', {}).get('value', '')
        lc_2nd_swift_code = lc_data.get('f57D_advise_through_bank', {}).get('value', '')
        lc_2nd_bank_name = lc_data.get('f57A_advise_through_bank', {}).get('value', '')

        contract_1st_swift_code = contract_data.get('advise_bank_swiftcode', {}).get('value', '')
        contract_1st_bank_name = contract_data.get('advise_bank', {}).get('value', '')
        contract_2nd_swift_code = contract_data.get('f57D_advise_through_bank', {}).get('value', '')
        contract_2nd_bank_name = contract_data.get('f57A_advise_through_bank', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_1st_swift_code=lc_1st_swift_code,
                lc_1st_bank_name=lc_1st_bank_name,
                lc_2nd_swift_code=lc_2nd_swift_code,
                lc_2nd_bank_name=lc_2nd_bank_name,
                contract_1st_swift_code=contract_1st_swift_code,
                contract_1st_bank_name=contract_1st_bank_name,
                contract_2nd_swift_code=contract_2nd_swift_code,
                contract_2nd_bank_name=contract_2nd_bank_name
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_1st_swift_code": lc_1st_swift_code,
            "lc_1st_bank_name": lc_1st_bank_name,
            "lc_2nd_swift_code": lc_2nd_swift_code,
            "lc_2nd_bank_name": lc_2nd_bank_name,
            "contract_1st_swift_code": contract_1st_swift_code,
            "contract_1st_bank_name": contract_1st_bank_name,
            "contract_2nd_swift_code": contract_2nd_swift_code,
            "contract_2nd_bank_name": contract_2nd_bank_name
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_date_of_expiry_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_expiry_date = lc_data.get('f31D_lc_expirydate', {}).get('value', '')
        contract_expiry_date = contract_data.get('f31D_lc_expirydate', {}).get('value', '')
        latest_shipment_date = contract_data.get('f44C_latest_date_of_ship', {}).get('value', '') or lc_data.get(
            'f44C_latest_date_of_ship', {}).get('value', '')
        period_of_presentation = contract_data.get('f48_period_of_present', {}).get('value', '') or lc_data.get(
            'f48_period_of_present', {}).get('value', '')
        lc_issuance_date = current_date

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_expiry_date=lc_expiry_date,
                contract_expiry_date=contract_expiry_date,
                latest_shipment_date=latest_shipment_date,
                period_of_presentation=period_of_presentation,
                lc_issuance_date=lc_issuance_date
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_expiry_date": lc_expiry_date,
            "contract_expiry_date": contract_expiry_date,
            "latest_shipment_date": latest_shipment_date,
            "period_of_presentation": period_of_presentation,
            "lc_issuance_date": lc_issuance_date
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_place_of_expiry_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_place_of_expiry = lc_data.get('f31D_place_of_expiry', {}).get('value', '')
        contract_place_of_expiry = contract_data.get('f31D_place_of_expiry', {}).get('value', '')
        contract_bank = contract_data.get('advise_bank', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_place_of_expiry=lc_place_of_expiry,
                contract_place_of_expiry=contract_place_of_expiry,
                contract_bank=contract_bank
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_place_of_expiry": lc_place_of_expiry,
            "contract_place_of_expiry": contract_place_of_expiry,
            "contract_bank": contract_bank
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_applicant_name_address_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_applicant = lc_data.get('f50_applicant_name_address', {}).get('value', '')
        lc_applicant_addr_2 = lc_data.get('f47A_additional_condition', {}).get('metadata', {}).get(
            'bct_47a_applicant_addr') or lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_buyer = contract_data.get('f50_applicant_name_address', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_applicant=lc_applicant,
                lc_applicant_addr_2=lc_applicant_addr_2,
                contract_buyer=contract_buyer
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_applicant": lc_applicant,
            "lc_applicant_addr_2": lc_applicant_addr_2,
            "contract_buyer": contract_buyer
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_benefic_name_address_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_beneficiary = lc_data.get('f59_benefic_name_address', {}).get('value', '')
        lc_beneficiary_addr_2 = lc_data.get('f47A_additional_condition', {}).get('metadata', {}).get(
            'bct_47a_ben_addr') or lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_seller = contract_data.get('f59_benefic_name_address', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_beneficiary=lc_beneficiary,
                lc_beneficiary_addr_2=lc_beneficiary_addr_2,
                contract_seller=contract_seller
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_beneficiary": lc_beneficiary,
            "lc_beneficiary_addr_2": lc_beneficiary_addr_2,
            "contract_seller": contract_seller
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_lc_amount_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_amount = lc_data.get('f32B_amount', {}).get('value', '') + ' ' + lc_data.get('f32B_currency_code', {}).get(
            'value', '')
        contract_amount = contract_data.get('f32B_amount', {}).get('value', '') + ' ' + contract_data.get(
            'f32B_currency_code', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_amount=lc_amount,
                contract_amount=contract_amount
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_amount": lc_amount,
            "contract_amount": contract_amount
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_amount_tolerance_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_credit_tolerance = lc_data.get('f39A_credit_tolerance', {}).get('value', '')
        lc_debit_tolerance = lc_data.get('f39A_debit_tolerance', {}).get('value', '')
        contract_credit_tolerance = contract_data.get('f39A_credit_tolerance', {}).get('value', '')
        contract_debit_tolerance = contract_data.get('f39A_debit_tolerance', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_credit_tolerance=lc_credit_tolerance,
                lc_debit_tolerance=lc_debit_tolerance,
                contract_credit_tolerance=contract_credit_tolerance,
                contract_debit_tolerance=contract_debit_tolerance
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_credit_tolerance": lc_credit_tolerance,
            "lc_debit_tolerance": lc_debit_tolerance,
            "contract_credit_tolerance": contract_credit_tolerance,
            "contract_debit_tolerance": contract_debit_tolerance
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_tenor_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_tenor = lc_data.get('tenor', {}).get('value', '')
        lc_additional_conditions = lc_data.get('f47A_additional_condition', {}).get('value', '')
        lc_documents_required = lc_data.get('f46A_documents_requires', {}).get('value', '')
        lc_reimbursing_bank = lc_data.get('reimbursing_bank', {}).get('value', '')
        contract_tenor = contract_data.get('tenor', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_tenor=lc_tenor,
                lc_additional_conditions=lc_additional_conditions,
                lc_documents_required=lc_documents_required,
                lc_reimbursing_bank=lc_reimbursing_bank,
                contract_tenor=contract_tenor
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_tenor": lc_tenor,
            "lc_additional_conditions": lc_additional_conditions,
            "lc_documents_required": lc_documents_required,
            "lc_reimbursing_bank": lc_reimbursing_bank,
            "contract_tenor": contract_tenor
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_partial_shipment_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_partial_shipment = lc_data.get('partial_shipment', {}).get('value', '')
        lc_additional_conditions = lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_partial_shipment = contract_data.get('partial_shipment', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_partial_shipment=lc_partial_shipment,
                lc_additional_conditions=lc_additional_conditions,
                contract_partial_shipment=contract_partial_shipment
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_partial_shipment": lc_partial_shipment,
            "lc_additional_conditions": lc_additional_conditions,
            "contract_partial_shipment": contract_partial_shipment
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_transhipment_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_transhipment = lc_data.get('transhipment', {}).get('value', '')
        lc_additional_conditions = lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_transhipment = contract_data.get('transhipment', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_transhipment=lc_transhipment,
                lc_additional_conditions=lc_additional_conditions,
                contract_transhipment=contract_transhipment
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_transhipment": lc_transhipment,
            "lc_additional_conditions": lc_additional_conditions,
            "contract_transhipment": contract_transhipment
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_place_of_receipt_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_place_of_receipt = lc_data.get('f44A_place_of_receipt', {}).get('value', '')
        lc_additional_conditions = lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_place_of_receipt = contract_data.get('f44A_place_of_receipt', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_place_of_receipt=lc_place_of_receipt,
                lc_additional_conditions=lc_additional_conditions,
                contract_place_of_receipt=contract_place_of_receipt
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_place_of_receipt": lc_place_of_receipt,
            "lc_additional_conditions": lc_additional_conditions,
            "contract_place_of_receipt": contract_place_of_receipt
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_port_of_loading_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_port_of_loading = lc_data.get('f44E_port_of_loading', {}).get('value', '') or lc_data.get(
            'airport_of_departure', {}).get('value', '')
        lc_place_of_receipt = lc_data.get('f44A_place_of_receipt', {}).get('value', '')
        lc_additional_conditions = lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_port_of_loading = contract_data.get('port_of_loading', {}).get('value', '') or contract_data.get(
            'airport_of_departure', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_port_of_loading=lc_port_of_loading,
                lc_place_of_receipt=lc_place_of_receipt,
                lc_additional_conditions=lc_additional_conditions,
                contract_port_of_loading=contract_port_of_loading
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_port_of_loading": lc_port_of_loading,
            "lc_place_of_receipt": lc_place_of_receipt,
            "lc_additional_conditions": lc_additional_conditions,
            "contract_port_of_loading": contract_port_of_loading
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_port_of_discharge_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_port_of_discharge = lc_data.get('f44F_port_of_discharge', {}).get('value', '') or lc_data.get(
            'airport_of_destination', {}).get('value', '')
        lc_final_destination = lc_data.get('final_destination', {}).get('value', '')
        lc_additional_conditions = lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_port_of_discharge = contract_data.get('port_of_discharge', {}).get('value', '') or contract_data.get(
            'airport_of_destination', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_port_of_discharge=lc_port_of_discharge,
                lc_final_destination=lc_final_destination,
                lc_additional_conditions=lc_additional_conditions,
                contract_port_of_discharge=contract_port_of_discharge
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_port_of_discharge": lc_port_of_discharge,
            "lc_final_destination": lc_final_destination,
            "lc_additional_conditions": lc_additional_conditions,
            "contract_port_of_discharge": contract_port_of_discharge
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_final_destination_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_final_destination = lc_data.get('final_destination', {}).get('value', '')
        lc_additional_conditions = lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_final_destination = contract_data.get('final_destination', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_final_destination=lc_final_destination,
                lc_additional_conditions=lc_additional_conditions,
                contract_final_destination=contract_final_destination
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_final_destination": lc_final_destination,
            "lc_additional_conditions": lc_additional_conditions,
            "contract_final_destination": contract_final_destination
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_latest_date_of_ship_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_latest_shipment_date = lc_data.get('f44C_latest_date_of_ship', {}).get('value', '')
        lc_additional_conditions = lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_latest_shipment_date = contract_data.get('f44C_latest_date_of_ship', {}).get('value', '')
        contract_date = contract_data.get('contract_date', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_latest_shipment_date=lc_latest_shipment_date,
                lc_additional_conditions=lc_additional_conditions,
                contract_latest_shipment_date=contract_latest_shipment_date,
                contract_date=contract_date
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_latest_shipment_date": lc_latest_shipment_date,
            "lc_additional_conditions": lc_additional_conditions,
            "contract_latest_shipment_date": contract_latest_shipment_date,
            "contract_date": contract_date
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_shipment_period_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_shipment_period = lc_data.get('f44D_shipment_period', {}).get('value', '')
        lc_latest_shipment_date = lc_data.get('f44C_latest_date_of_ship', {}).get('value', '')
        lc_additional_conditions = lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_shipment_period = contract_data.get('f44D_shipment_period', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_shipment_period=lc_shipment_period,
                lc_latest_shipment_date=lc_latest_shipment_date,
                lc_additional_conditions=lc_additional_conditions,
                contract_shipment_period=contract_shipment_period
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_shipment_period": lc_shipment_period,
            "lc_latest_shipment_date": lc_latest_shipment_date,
            "lc_additional_conditions": lc_additional_conditions,
            "contract_shipment_period": contract_shipment_period
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_period_presentation_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_period_presentation = lc_data.get('f48_period_of_present', {}).get('value', '')
        lc_additional_conditions = lc_data.get('f47A_additional_condition', {}).get('value', '')
        contract_period_presentation = contract_data.get('f48_period_of_present', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_period_presentation=lc_period_presentation,
                lc_additional_conditions=lc_additional_conditions,
                contract_period_presentation=contract_period_presentation
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_period_presentation": lc_period_presentation,
            "lc_additional_conditions": lc_additional_conditions,
            "contract_period_presentation": contract_period_presentation
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_goods_service_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_goods_service = lc_data.get('f45A_goods_services', {}).get('value', '')
        contract_goods_service = contract_data.get('f45A_goods_services', {}).get('value', '')
        goods_services_metadata = contract_data.get('f45A_goods_services', {}).get('metadata', {})

        contract_goods_service_detail = ""
        quality = goods_services_metadata.get('bct_45a_quality', '')
        origin = goods_services_metadata.get('bct_45a_origin', '')
        trade_term = contract_data.get('f45A_goods_services_trade_term', {}).get("value", "")
        incoterm = contract_data.get('f45A_goods_services_incoterm', {}).get("value", "")
        contract_goods_service_detail += f"\n**QUALITY**: {quality} \n **ORIGIN**: {origin} \n **TRADE TERM**: {trade_term} **Incoterms**: {incoterm}\n"

        if goods_services_metadata:
            commodity = goods_services_metadata.get('bct_45a_desc_goods', {})
            if commodity:
                for i, c in enumerate(commodity):
                    quantity_value = c.get('bct_45a_quantity_value', '') + ' ' + c.get('bct_45a_quantity_unit', '')
                    commodity_name = c.get('bct_45a_commodity', '')
                    unit_price = c.get('bct_45a_uprice_amount', '') + ' ' + c.get('bct_45a_uprice_currency',
                                                                                '') + '/' + c.get(
                        'bct_45a_uprice_unit', '')
                    total_amount = c.get('bct_45a_total_amount_value', '') + ' ' + c.get('bct_45a_total_amount_unit',
                                                                                        '')
                    stt = str(i + 1)
                    contract_goods_service_detail += f"{stt}. COMMODITY: {commodity_name}; QUANTITY: {quantity_value}; UNIT PRICE: {unit_price}; AMOUNT: {total_amount}\n"

        lc_amount = lc_data.get('f32B_amount', {}).get('value', '')
        contract_amount = contract_data.get('f32B_amount', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_goods_service=lc_goods_service,
                lc_amount=lc_amount,
                contract_goods_service=contract_goods_service,
                contract_goods_service_detail=contract_goods_service_detail,
                contract_amount=contract_amount
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_goods_service": lc_goods_service,
            "lc_amount": lc_amount,
            "contract_goods_service": contract_goods_service,
            "contract_goods_service_detail": contract_goods_service_detail,
            "contract_amount": contract_amount
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response

    async def check_documents_required_details_es2(self, request_data, rule, business_entity):
        flow_code_data = request_data[0].model_dump()

        contract_data = [d for d in request_data[0].documents if d.document_code == self.contract_document_code][
            0].model_dump().get('metadata')
        lc_data = [d for d in request_data[0].documents if d.document_code == self.lc_document_code]

        if len(lc_data) == 0:
            response = OverallResponse(
                soa_code='AI_OCR_0001',
                soa_desc='',
                comment='',
                matched=Matched.ERROR,
                type=Type.COMPLIANCE,
                code=flow_code_data.get("code"),
                rule_code=rule.rule_code,
                rule_name=rule.rule_name,
                group_code=rule.group_code,
                group_name=rule.group_name
            )
            return response
        else:
            lc_data = lc_data[0].model_dump().get('metadata')

        lc_documents_required = lc_data.get('f46A_documents_requires', {}).get('value', '')
        contract_documents_required = contract_data.get('f46A_documents_requires', {}).get('value', '')

        messages = []
        for prompt in rule.messages[0].prompt:
            messages.append(prompt.dict())

        if len(messages) > 1:
            messages[1]['content'] = messages[1]['content'].format(
                lc_documents_required=lc_documents_required,
                contract_documents_required=contract_documents_required
            )

        response_gpt = parse(messages=messages,
                            base_url=business_entity.openai.base_url,
                            api_version=business_entity.openai.api_version,
                            api_key=business_entity.openai.api_key,
                            temperature=0,
                            top_p=None,
                            client_message_id=flow_code_data.get("flow_code"))

        response_text = response_gpt.choices[0].message.content.strip()
        response_data = load_json_gpt(response_text)

        field_values = {
            "lc_documents_required": lc_documents_required,
            "contract_documents_required": contract_documents_required
        }

        inputs_with_values = self.fill_input_values(rule.inputs, field_values)

        response = OverallResponse(
            soa_code='AI_OCR_0001',
            soa_desc=mapping_case_final.get(rule.rule_code).get(response_data.get('case')) if not response_data.get(
                'is_compliance') else '',
            comment=response_data.get('explanation'),
            matched=Matched.SUCCESS if response_data.get('is_compliance') else Matched.ERROR,
            details=[Detail(
                inputs=inputs_with_values,
                conclusion=response_data.get('is_comnpliance'),
                answer=response_data.get('explanation')
            )],
            type=Type.COMPLIANCE,
            code=flow_code_data.get("code"),
            rule_code=rule.rule_code,
            rule_name=rule.rule_name,
            group_code=rule.group_code,
            group_name=rule.group_name
        )
        return response